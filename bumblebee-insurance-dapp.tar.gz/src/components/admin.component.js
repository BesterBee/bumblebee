import './admin.nav.css'
import React, {Component} from "react";
import { Link } from 'react-router-dom';

//Components
import SidePanel from "./admin/sidepanel.component";
import Home from "./admin/home.component";
import Policies from "./admin.component";
import Claims from "./admin.component";




export default class AdminPanel extends Component{

    render(){
        return(
            <div className= 'row'>
                <div className='col-4'>
                    <SidePanel/>
                </div>


            </div>
             
               
               


        )
    }

}