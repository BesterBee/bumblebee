import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

// Components
import Navbar from './components/navbar.component';
import Landing from './components/landing.component';


// User
import NewClaim from './components/newclaim.component';
import ViewClaims from './components/viewclaims.component';
import ViewPolicies from './components/viewpolicies.component';

// Admin
import NewPolicy from './components/newpolicy.component';
import AdminPanel from './components/admin.component';

// Basic App Functionality
function App() {
  return (
    
    <Router>
      <div className='container'>

      </div>
      <Navbar />
      <Routes>
        
        <Route path="/" element= {<Landing/>}/>
        <Route path='viewclaims/new'element={<NewClaim/>}/>
        <Route path="viewpolicies/new"element= {<NewPolicy/>}/>
        <Route path="viewclaims" element= {<ViewClaims/>}/>
        <Route path="viewpolicies" element= {<ViewPolicies/>}/>

        <Route path='admin' element={<AdminPanel/>}/>
        
      </Routes> 
    </Router>
   
  );
}

export default App;
